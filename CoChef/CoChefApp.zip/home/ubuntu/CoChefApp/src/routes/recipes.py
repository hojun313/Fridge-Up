# /home/ubuntu/CoChefApp/src/routes/recipes.py
from flask import Blueprint, request, jsonify, render_template, redirect, url_for, flash
from flask_login import login_required, current_user
from src.models import db, Recipe, Ingredient # Assuming Ingredient model is needed to check available ingredients
import os # For dummy template creation

recipes_bp = Blueprint("recipes", __name__)

# Dummy recipe data (in a real app, this would come from the database or an external API)
DUMMY_RECIPES = [
    Recipe(id=1, name="Apple Pie", description="Classic homemade apple pie.", ingredients_required="Apples, Flour, Sugar, Butter, Cinnamon", instructions="1. Make crust. 2. Prepare apple filling. 3. Assemble pie. 4. Bake."),
    Recipe(id=2, name="Tomato Soup", description="Comforting tomato soup.", ingredients_required="Tomatoes, Onion, Garlic, Vegetable Broth, Cream", instructions="1. Sauté onions and garlic. 2. Add tomatoes and broth. 3. Simmer. 4. Blend. 5. Stir in cream."),
    Recipe(id=3, name="Chicken Stir-fry", description="Quick and easy chicken stir-fry.", ingredients_required="Chicken, Broccoli, Bell Peppers, Soy Sauce, Ginger, Garlic", instructions="1. Cook chicken. 2. Add vegetables. 3. Make sauce. 4. Combine and serve."),
    Recipe(id=4, name="Omelette", description="Simple Omelette.", ingredients_required="Eggs, Milk, Cheese, Salt, Pepper", instructions="1. Whisk eggs and milk. 2. Pour into pan. 3. Add cheese. 4. Fold and cook.")
]

# Helper to create dummy templates if they don't exist for now
@recipes_bp.route("/_create_dummy_recipe_templates", methods=["GET"])
@login_required
def _create_dummy_recipe_templates():
    template_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "static")
    if not os.path.exists(template_dir):
        os.makedirs(template_dir)

    recommendations_html_content = """
    <!DOCTYPE html><html><head><title>Recipe Recommendations</title></head><body>
    <h2>Recipe Recommendations</h2>
    {% with messages = get_flashed_messages(with_categories=true) %}
      {% if messages %}
        <ul>
        {% for category, message in messages %}
          <li class="{{ category }}">{{ message }}</li>
        {% endfor %}
        </ul>
      {% endif %}
    {% endwith %}
    <p>Based on your available ingredients:</p>
    {% if recommended_recipes %}
        <ul>
        {% for recipe in recommended_recipes %}
            <li>
                <strong><a href="{{ url_for(\'recipes.view_recipe_page\', recipe_id=recipe.id) }}">{{ recipe.name }}</a></strong>
                <p>{{ recipe.description }}</p>
            </li>
        {% endfor %}
        </ul>
    {% else %}
        <p>No recipes found that you can make with your current ingredients. Try adding more ingredients!</p>
    {% endif %}
    <p><a href="{{ url_for(\'index\') }}">Back to Home</a></p>
    </body></html>
    """
    recipe_detail_html_content = """
    <!DOCTYPE html><html><head><title>{{ recipe.name }}</title></head><body>
    <h2>{{ recipe.name }}</h2>
    {% with messages = get_flashed_messages(with_categories=true) %}
      {% if messages %}
        <ul>
        {% for category, message in messages %}
          <li class="{{ category }}">{{ message }}</li>
        {% endfor %}
        </ul>
      {% endif %}
    {% endwith %}
    <p><strong>Description:</strong> {{ recipe.description }}</p>
    <p><strong>Ingredients Required:</strong></p>
    <ul>
        {% for item in recipe.ingredients_required.split(\",\") %}
            <li>{{ item.strip() }}</li>
        {% endfor %}
    </ul>
    <p><strong>Instructions:</strong></p>
    <p>{{ recipe.instructions | safe }}</p> {# Use safe if instructions can contain HTML #}
    {% if recipe.source_url %}
        <p><strong>Source:</strong> <a href="{{ recipe.source_url }}" target="_blank">{{ recipe.source_url }}</a></p>
    {% endif %}
    <p><a href="{{ url_for(\'recipes.recommend_recipes_page\') }}">Back to Recommendations</a></p>
    <p><a href="{{ url_for(\'index\') }}">Back to Home</a></p>
    </body></html>
    """

    with open(os.path.join(template_dir, "recommendations.html"), "w") as f:
        f.write(recommendations_html_content)
    with open(os.path.join(template_dir, "recipe_detail.html"), "w") as f:
        f.write(recipe_detail_html_content)
    return "Dummy recipe templates created/updated."


# HTML Page for Recipe Recommendations
@recipes_bp.route("/recommend/page", methods=["GET"])
@login_required
def recommend_recipes_page():
    user_ingredients = Ingredient.query.filter_by(user_id=current_user.id).all()
    available_ingredient_names = {ing.name.lower() for ing in user_ingredients}

    recommended_recipes = []
    # In a real app, recipes would be queried from the db
    # For now, using DUMMY_RECIPES and a simple matching logic
    all_recipes_from_db = Recipe.query.all() # or DUMMY_RECIPES if db is not populated yet
    if not all_recipes_from_db:
        # Populate dummy recipes if DB is empty for testing
        # This should ideally be a one-time seed script
        try:
            for r_data in DUMMY_RECIPES:
                # Check if recipe already exists by name to avoid duplicates if this is run multiple times
                exists = Recipe.query.filter_by(name=r_data.name).first()
                if not exists:
                    # Create a new Recipe instance. Note: DUMMY_RECIPES are already Recipe instances.
                    # If they were dicts, you would do: new_recipe = Recipe(**r_data)
                    db.session.add(r_data) # Add the instance directly
            db.session.commit()
            all_recipes_from_db = Recipe.query.all()
        except Exception as e:
            db.session.rollback()
            print(f"Error populating dummy recipes: {e}")
            flash("Error loading initial recipes.", "danger")

    for recipe in all_recipes_from_db:
        required = {item.strip().lower() for item in recipe.ingredients_required.split(",")}
        if required.issubset(available_ingredient_names):
            recommended_recipes.append(recipe)
    
    if not recommended_recipes and not all_recipes_from_db:
        flash("No recipes available in the system yet.", "info")
    elif not recommended_recipes:
        flash("Could not find any recipes you can make with your current ingredients.", "info")

    return render_template("recommendations.html", recommended_recipes=recommended_recipes)

# HTML Page for a specific recipe
@recipes_bp.route("/<int:recipe_id>/page", methods=["GET"])
@login_required # Or remove if recipes can be viewed by anyone
def view_recipe_page(recipe_id):
    recipe = Recipe.query.get_or_404(recipe_id)
    # If using DUMMY_RECIPES and DB might be empty:
    # recipe = next((r for r in DUMMY_RECIPES if r.id == recipe_id), None)
    # if not recipe:
    #     return "Recipe not found", 404
    return render_template("recipe_detail.html", recipe=recipe)


# API to get recipe recommendations
@recipes_bp.route("/recommend", methods=["GET"])
@login_required
def recommend_recipes_api():
    user_ingredients = Ingredient.query.filter_by(user_id=current_user.id).all()
    available_ingredient_names = {ing.name.lower() for ing in user_ingredients}

    recommended_recipes_data = []
    all_recipes_from_db = Recipe.query.all()
    if not all_recipes_from_db and DUMMY_RECIPES: # Fallback for testing if DB is empty
        all_recipes_from_db = DUMMY_RECIPES

    for recipe in all_recipes_from_db:
        required = {item.strip().lower() for item in recipe.ingredients_required.split(",")}
        if required.issubset(available_ingredient_names):
            recommended_recipes_data.append(recipe.to_dict())
    
    if not recommended_recipes_data:
        return jsonify({"message": "No recipes found that you can make with your current ingredients."}), 200 # Or 404 if preferred

    return jsonify(recommended_recipes_data), 200

# API to get a specific recipe by ID
@recipes_bp.route("/<int:recipe_id>", methods=["GET"])
# @login_required # Optional: if recipes are public, no login needed
def get_recipe_api(recipe_id):
    recipe = Recipe.query.get_or_404(recipe_id)
    # Fallback for testing if DB is empty
    # if not recipe and DUMMY_RECIPES:
    #     recipe_obj = next((r for r in DUMMY_RECIPES if r.id == recipe_id), None)
    #     if recipe_obj:
    #         return jsonify(recipe_obj.to_dict()), 200
    #     else:
    #         return jsonify({"message": "Recipe not found"}), 404
    return jsonify(recipe.to_dict()), 200

# (Optional) API for 쿠팡 shopping link - as per architecture_design.md
@recipes_bp.route("/shopping_link", methods=["GET"])
@login_required # Or public if preferred
def shopping_link_api():
    item_name = request.args.get("item")
    if not item_name:
        return jsonify({"message": "Item name is required for shopping link."}), 400
    
    # Basic Coupang search URL structure
    # In a real app, you might use an affiliate API or a more robust search
    search_query = item_name.replace(" ", "+")
    shopping_url = f"https://www.coupang.com/np/search?q={search_query}"
    return jsonify({"item_name": item_name, "shopping_url": shopping_url}), 200

