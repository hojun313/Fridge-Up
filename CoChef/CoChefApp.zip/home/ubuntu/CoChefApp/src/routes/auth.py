# /home/ubuntu/CoChefApp/src/routes/auth.py
from flask import Blueprint, request, jsonify, render_template, redirect, url_for, flash
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from src.models import db, User

auth_bp = Blueprint("auth", __name__)

@auth_bp.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("index")) # Redirect to main page if already logged in
    if request.method == "POST":
        data = request.get_json() or request.form
        username = data.get("username")
        password = data.get("password")

        if not username or not password:
            flash("Username and password are required.", "danger")
            # For API requests, return JSON
            if request.is_json:
                return jsonify({"message": "Username and password are required."}), 400
            return render_template("register.html") # Or your registration template

        if User.query.filter_by(username=username).first():
            flash("Username already exists.", "warning")
            if request.is_json:
                return jsonify({"message": "Username already exists."}), 409
            return render_template("register.html")

        new_user = User(username=username)
        new_user.set_password(password)
        db.session.add(new_user)
        db.session.commit()
        flash("Registration successful! Please log in.", "success")
        if request.is_json:
            return jsonify({"message": "User registered successfully"}), 201
        return redirect(url_for("auth.login"))
    # For GET request, show the registration form
    return render_template("register.html") # Ensure this template exists

@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("index"))
    if request.method == "POST":
        data = request.get_json() or request.form
        username = data.get("username")
        password = data.get("password")
        remember = True if data.get("remember") else False

        user = User.query.filter_by(username=username).first()

        if not user or not user.check_password(password):
            flash("Invalid username or password.", "danger")
            if request.is_json:
                return jsonify({"message": "Invalid username or password."}), 401
            return render_template("login.html") # Ensure this template exists

        login_user(user, remember=remember)
        flash("Logged in successfully!", "success")
        if request.is_json:
            # For API login, you might return a token or session info
            return jsonify({"message": "Logged in successfully", "user": {"id": user.id, "username": user.username}}), 200
        
        # Redirect to the page user was trying to access, or to index
        next_page = request.args.get("next")
        return redirect(next_page or url_for("index"))
        
    return render_template("login.html")

@auth_bp.route("/logout")
@login_required
def logout():
    logout_user()
    flash("You have been logged out.", "info")
    if request.is_json:
        return jsonify({"message": "Logged out successfully"}), 200
    return redirect(url_for("auth.login"))

@auth_bp.route("/status")
@login_required # Or remove if status can be checked without login for some reason
def status():
    if current_user.is_authenticated:
        return jsonify({"logged_in": True, "user": {"id": current_user.id, "username": current_user.username}}), 200
    else:
        return jsonify({"logged_in": False}), 200 # Or 401 if login is strictly required to check status

# Helper to create dummy templates if they don't exist for now
@auth_bp.route("/_create_dummy_templates", methods=["GET"])
def _create_dummy_templates():
    template_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "static")
    if not os.path.exists(template_dir):
        os.makedirs(template_dir)
    
    login_html_content = """
    <!DOCTYPE html><html><head><title>Login</title></head><body>
    <h2>Login</h2>
    {% with messages = get_flashed_messages(with_categories=true) %}
      {% if messages %}
        <ul>
        {% for category, message in messages %}
          <li class="{{ category }}">{{ message }}</li>
        {% endfor %}
        </ul>
      {% endif %}
    {% endwith %}
    <form method="post">
        Username: <input type="text" name="username"><br>
        Password: <input type="password" name="password"><br>
        <input type="checkbox" name="remember"> Remember Me<br>
        <input type="submit" value="Login">
    </form>
    <p>Don't have an account? <a href="{{ url_for('auth.register') }}">Register here</a></p>
    </body></html>
    """
    register_html_content = """
    <!DOCTYPE html><html><head><title>Register</title></head><body>
    <h2>Register</h2>
    {% with messages = get_flashed_messages(with_categories=true) %}
      {% if messages %}
        <ul>
        {% for category, message in messages %}
          <li class="{{ category }}">{{ message }}</li>
        {% endfor %}
        </ul>
      {% endif %}
    {% endwith %}
    <form method="post">
        Username: <input type="text" name="username"><br>
        Password: <input type="password" name="password"><br>
        <input type="submit" value="Register">
    </form>
    <p>Already have an account? <a href="{{ url_for('auth.login') }}">Login here</a></p>
    </body></html>
    """
    index_html_content = """
    <!DOCTYPE html><html><head><title>CoChef App</title></head><body>
    <h1>Welcome to CoChef App</h1>
    {% with messages = get_flashed_messages(with_categories=true) %}
      {% if messages %}
        <ul>
        {% for category, message in messages %}
          <li class="{{ category }}">{{ message }}</li>
        {% endfor %}
        </ul>
      {% endif %}
    {% endwith %}
    {% if current_user.is_authenticated %}
        <p>Hello, {{ current_user.username }}! <a href="{{ url_for('auth.logout') }}">Logout</a></p>
        <p><a href="{{ url_for('ingredients.list_ingredients_page') }}">Manage Ingredients</a></p>
        <p><a href="{{ url_for('recipes.recommend_recipes_page') }}">Get Recipe Recommendations</a></p>
    {% else %}
        <p><a href="{{ url_for('auth.login') }}">Login</a> or <a href="{{ url_for('auth.register') }}">Register</a></p>
    {% endif %}
    </body></html>
    """

    with open(os.path.join(template_dir, "login.html"), "w") as f:
        f.write(login_html_content)
    with open(os.path.join(template_dir, "register.html"), "w") as f:
        f.write(register_html_content)
    # index.html will be created by main.py or here if needed
    if not os.path.exists(os.path.join(template_dir, "index.html")):
         with open(os.path.join(template_dir, "index.html"), "w") as f:
            f.write(index_html_content)

    return "Dummy templates created/updated."

