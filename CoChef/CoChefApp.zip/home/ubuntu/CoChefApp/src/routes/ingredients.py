# /home/ubuntu/CoChefApp/src/routes/ingredients.py
from flask import Blueprint, request, jsonify, render_template, redirect, url_for, flash
from flask_login import login_required, current_user
from src.models import db, Ingredient, User
from datetime import datetime, date

ingredients_bp = Blueprint("ingredients", __name__)

# Helper to create dummy templates if they don't exist for now
@ingredients_bp.route("/_create_dummy_ingredient_templates", methods=["GET"])
@login_required
def _create_dummy_ingredient_templates():
    import os
    template_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "static")
    if not os.path.exists(template_dir):
        os.makedirs(template_dir)

    ingredients_html_content = """
    <!DOCTYPE html><html><head><title>My Ingredients</title></head><body>
    <h2>My Ingredients</h2>
    {% with messages = get_flashed_messages(with_categories=true) %}
      {% if messages %}
        <ul>
        {% for category, message in messages %}
          <li class="{{ category }}">{{ message }}</li>
        {% endfor %}
        </ul>
      {% endif %}
    {% endwith %}
    <h3>Add New Ingredient</h3>
    <form method="post" action="{{ url_for('ingredients.add_ingredient_api') }}">
        Name: <input type="text" name="name" required><br>
        Expiry Date (YYYY-MM-DD): <input type="date" name="expiry_date"><br>
        Quantity: <input type="text" name="quantity"><br>
        Purchase Date (YYYY-MM-DD): <input type="date" name="purchase_date"><br>
        <input type="submit" value="Add Ingredient">
    </form>
    <hr>
    <h3>Your Current Ingredients (Sorted by Expiry Date)</h3>
    {% if ingredients %}
        <ul>
        {% for ingredient in ingredients %}
            <li>
                <strong>{{ ingredient.name }}</strong> - Expires: {{ ingredient.expiry_date if ingredient.expiry_date else 'N/A' }} (Quantity: {{ ingredient.quantity if ingredient.quantity else 'N/A' }})
                <form method="post" action="{{ url_for('ingredients.delete_ingredient_api', ingredient_id=ingredient.id) }}" style="display:inline;">
                    <input type="submit" value="Delete">
                </form>
                 <a href="{{ url_for('ingredients.edit_ingredient_page', ingredient_id=ingredient.id) }}">Edit</a>
            </li>
        {% endfor %}
        </ul>
    {% else %}
        <p>You have no ingredients yet.</p>
    {% endif %}
    <p><a href="{{ url_for('index') }}">Back to Home</a></p>
    </body></html>
    """
    edit_ingredient_html_content = """
    <!DOCTYPE html><html><head><title>Edit Ingredient</title></head><body>
    <h2>Edit Ingredient: {{ ingredient.name }}</h2>
    {% with messages = get_flashed_messages(with_categories=true) %}
      {% if messages %}
        <ul>
        {% for category, message in messages %}
          <li class="{{ category }}">{{ message }}</li>
        {% endfor %}
        </ul>
      {% endif %}
    {% endwith %}
    <form method="post" action="{{ url_for('ingredients.edit_ingredient_api', ingredient_id=ingredient.id) }}">
        Name: <input type="text" name="name" value="{{ ingredient.name }}" required><br>
        Expiry Date (YYYY-MM-DD): <input type="date" name="expiry_date" value="{{ ingredient.expiry_date.isoformat() if ingredient.expiry_date else '' }}"><br>
        Quantity: <input type="text" name="quantity" value="{{ ingredient.quantity if ingredient.quantity else '' }}"><br>
        Purchase Date (YYYY-MM-DD): <input type="date" name="purchase_date" value="{{ ingredient.purchase_date.isoformat() if ingredient.purchase_date else '' }}"><br>
        <input type="submit" value="Update Ingredient">
    </form>
    <p><a href="{{ url_for('ingredients.list_ingredients_page') }}">Back to Ingredients</a></p>
    </body></html>
    """

    with open(os.path.join(template_dir, "ingredients.html"), "w") as f:
        f.write(ingredients_html_content)
    with open(os.path.join(template_dir, "edit_ingredient.html"), "w") as f:
        f.write(edit_ingredient_html_content)
    return "Dummy ingredient templates created/updated."

# HTML Page to display and manage ingredients
@ingredients_bp.route("/page", methods=["GET"])
@login_required
def list_ingredients_page():
    # Sort by expiry_date, nulls last (or first, depending on desired behavior for no expiry)
    ingredients = Ingredient.query.filter_by(user_id=current_user.id).order_by(Ingredient.expiry_date.asc().nullslast()).all()
    return render_template("ingredients.html", ingredients=ingredients)

# HTML Page to edit an ingredient
@ingredients_bp.route("/<int:ingredient_id>/edit_page", methods=["GET"])
@login_required
def edit_ingredient_page(ingredient_id):
    ingredient = Ingredient.query.get_or_404(ingredient_id)
    if ingredient.user_id != current_user.id:
        flash("You are not authorized to edit this ingredient.", "danger")
        return redirect(url_for("ingredients.list_ingredients_page"))
    return render_template("edit_ingredient.html", ingredient=ingredient)

# API to add a new ingredient
@ingredients_bp.route("/", methods=["POST"])
@login_required
def add_ingredient_api():
    data = request.get_json() or request.form
    name = data.get("name")
    expiry_date_str = data.get("expiry_date")
    quantity = data.get("quantity")
    purchase_date_str = data.get("purchase_date")

    if not name:
        flash("Ingredient name is required.", "danger")
        if request.is_json:
            return jsonify({"message": "Ingredient name is required."}), 400
        return redirect(url_for("ingredients.list_ingredients_page"))

    expiry_date = None
    if expiry_date_str:
        try:
            expiry_date = datetime.strptime(expiry_date_str, "%Y-%m-%d").date()
        except ValueError:
            flash("Invalid expiry date format. Please use YYYY-MM-DD.", "danger")
            if request.is_json:
                return jsonify({"message": "Invalid expiry date format. Please use YYYY-MM-DD."}), 400
            return redirect(url_for("ingredients.list_ingredients_page"))
    else: # Default expiry date if not provided, as per requirements
        expiry_date = date(2099, 12, 31)

    purchase_date = None
    if purchase_date_str:
        try:
            purchase_date = datetime.strptime(purchase_date_str, "%Y-%m-%d").date()
        except ValueError:
            flash("Invalid purchase date format. Please use YYYY-MM-DD.", "danger")
            if request.is_json:
                return jsonify({"message": "Invalid purchase date format. Please use YYYY-MM-DD."}), 400
            return redirect(url_for("ingredients.list_ingredients_page"))

    new_ingredient = Ingredient(
        user_id=current_user.id,
        name=name,
        expiry_date=expiry_date,
        quantity=quantity,
        purchase_date=purchase_date
    )
    db.session.add(new_ingredient)
    db.session.commit()
    flash(f"Ingredient '{new_ingredient.name}' added successfully!", "success")
    if request.is_json:
        return jsonify({"message": f"Ingredient '{new_ingredient.name}' added successfully!", "ingredient": new_ingredient.to_dict()}), 201
    return redirect(url_for("ingredients.list_ingredients_page"))

# API to get all ingredients for the current user
@ingredients_bp.route("/", methods=["GET"])
@login_required
def get_ingredients_api():
    ingredients = Ingredient.query.filter_by(user_id=current_user.id).order_by(Ingredient.expiry_date.asc().nullslast()).all()
    return jsonify([ingredient.to_dict() for ingredient in ingredients]), 200

# API to get, update, or delete a specific ingredient
@ingredients_bp.route("/<int:ingredient_id>", methods=["GET", "PUT", "DELETE"])
@login_required
def manage_ingredient_api(ingredient_id):
    ingredient = Ingredient.query.get_or_404(ingredient_id)

    if ingredient.user_id != current_user.id:
        flash("You are not authorized to manage this ingredient.", "danger")
        if request.is_json:
            return jsonify({"message": "Unauthorized"}), 403
        return redirect(url_for("ingredients.list_ingredients_page"))

    if request.method == "GET":
        return jsonify(ingredient.to_dict()), 200

    if request.method == "PUT":
        data = request.get_json() or request.form
        ingredient.name = data.get("name", ingredient.name)
        expiry_date_str = data.get("expiry_date")
        if expiry_date_str:
            try:
                ingredient.expiry_date = datetime.strptime(expiry_date_str, "%Y-%m-%d").date()
            except ValueError:
                flash("Invalid expiry date format for update. Please use YYYY-MM-DD.", "danger")
                if request.is_json:
                    return jsonify({"message": "Invalid expiry date format. Please use YYYY-MM-DD."}), 400
                return redirect(url_for("ingredients.edit_ingredient_page", ingredient_id=ingredient.id))
        elif "expiry_date" in data and not expiry_date_str: # Explicitly setting to null or default
             ingredient.expiry_date = date(2099,12,31) # Or None if you prefer null
        
        purchase_date_str = data.get("purchase_date")
        if purchase_date_str:
            try:
                ingredient.purchase_date = datetime.strptime(purchase_date_str, "%Y-%m-%d").date()
            except ValueError:
                flash("Invalid purchase date format for update. Please use YYYY-MM-DD.", "danger")
                if request.is_json:
                    return jsonify({"message": "Invalid purchase date format. Please use YYYY-MM-DD."}), 400
                return redirect(url_for("ingredients.edit_ingredient_page", ingredient_id=ingredient.id))
        elif "purchase_date" in data and not purchase_date_str:
            ingredient.purchase_date = None

        ingredient.quantity = data.get("quantity", ingredient.quantity)
        ingredient.updated_at = datetime.utcnow()
        db.session.commit()
        flash(f"Ingredient \'{ingredient.name}\' updated successfully!", "success")
        if request.is_json:
            return jsonify({"message": f"Ingredient \'{ingredient.name}\' updated successfully!", "ingredient": ingredient.to_dict()}), 200
        return redirect(url_for("ingredients.list_ingredients_page"))

    if request.method == "DELETE":
        ingredient_name = ingredient.name # Save name before deleting for the message
        db.session.delete(ingredient)
        db.session.commit()
        flash(f"Ingredient \'{ingredient_name}\' deleted successfully!", "success")
        if request.is_json:
            return jsonify({"message": f"Ingredient \'{ingredient_name}\' deleted successfully!"}), 200
        return redirect(url_for("ingredients.list_ingredients_page"))

