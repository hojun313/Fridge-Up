# /home/ubuntu/CoChefApp/src/main.py
import sys
import os

# THIS IS VERY IMPORTANT. DO NOT REMOVE OR MODIFY THIS LINE.
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask, jsonify, render_template
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate # For database migrations
from flask_login import LoginManager, current_user # For user sessions

# Import models and db instance
from src.models import db, User, Ingredient, Recipe # Updated import

# Application Factory
def create_app(config_name='development'): # Added config_name for flexibility
    app = Flask(__name__, static_folder='static', template_folder='static') # Serve static files from static folder

    # Configuration
    # In a real app, use instance-relative config or environment variables
    app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'your_secret_key_here_change_me')
    # Database configuration - IMPORTANT: Uncomment and configure for MySQL
    # Ensure DB_USERNAME, DB_PASSWORD, DB_HOST, DB_PORT, DB_NAME are set as environment variables or replace them directly.
    # For local development, you might use SQLite or the provided MySQL service.
    db_user = os.getenv('DB_USERNAME', 'root')
    db_password = os.getenv('DB_PASSWORD', 'password')
    db_host = os.getenv('DB_HOST', 'localhost') # or the IP of your MySQL container if using Docker
    db_port = os.getenv('DB_PORT', '3306')
    db_name = os.getenv('DB_NAME', 'cochef_db') # Changed from 'mydb' to 'cochef_db' for clarity
    # app.config["SQLALCHEMY_DATABASE_URI"] = f"mysql+pymysql://{db_user}:{db_password}@{db_host}:{db_port}/{db_name}"
    app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL") or \
        "sqlite:///" + os.path.join(os.path.abspath(os.path.dirname(__file__)), "app.db") # Default to SQLite
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

    # Initialize extensions
    db.init_app(app) # Initialize db with the app
    migrate = Migrate(app, db) # Initialize Flask-Migrate

    # Flask-Login setup
    login_manager = LoginManager()
    login_manager.init_app(app)
    login_manager.login_view = 'auth.login'  # The route for the login page (blueprint.route_function_name)
    login_manager.login_message_category = 'info'

    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))

    # Import and register blueprints
    from src.routes.auth import auth_bp
    from src.routes.ingredients import ingredients_bp
    from src.routes.recipes import recipes_bp
    # from src.routes.main_routes import main_bp # For general routes like index, about

    app.register_blueprint(auth_bp, url_prefix='/auth')
    app.register_blueprint(ingredients_bp, url_prefix='/api/ingredients')
    app.register_blueprint(recipes_bp, url_prefix='/api/recipes')
    # app.register_blueprint(main_bp)

    # A simple default route for testing
    @app.route('/')
    def index():
        # This will serve index.html from the 'static' folder
        # Ensure you have an index.html file there.
        return render_template("index.html", current_user=current_user)

    @app.route('/hello')
    def hello():
        return jsonify(message="Hello from CoChef App!")

    # Create database tables if they don't exist
    # This is generally handled by migrations in a production app (e.g., flask db init, flask db migrate, flask db upgrade)
    # For simplicity in this template, we can create them directly if needed for initial setup.
    with app.app_context():
        # Check if the database needs to be created
        # from sqlalchemy_utils import database_exists, create_database
        # if not database_exists(app.config['SQLALCHEMY_DATABASE_URI']):
        #     create_database(app.config['SQLALCHEMY_DATABASE_URI'])
        #     print(f"Database {db_name} created.")
        # else:
        #     print(f"Database {db_name} already exists.")
        db.create_all() # Creates tables from SQLAlchemy models
        print("Database tables created/verified.")

    return app

if __name__ == '__main__':
    # This allows running the app directly using `python src/main.py`
    # For production, use a WSGI server like Gunicorn or uWSGI
    app = create_app()
    app.run(host='0.0.0.0', port=5000, debug=True) # Runs on port 5000, accessible externally

