# /home/ubuntu/CoChefApp/src/models/recipe.py
from datetime import datetime
from .user import db # Import db from user.py or a central db initialization file

class Recipe(db.Model):
    __tablename__ = 'recipes'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=True)
    ingredients_required = db.Column(db.Text, nullable=False) # Stores a comma-separated list or JSON string of ingredients
    instructions = db.Column(db.Text, nullable=False)
    source_url = db.Column(db.String(255), nullable=True)
    # user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True) # Optional: if recipes can be user-specific
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def __repr__(self):
        return f'<Recipe {self.name}>'

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'ingredients_required': self.ingredients_required,
            'instructions': self.instructions,
            'source_url': self.source_url,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat()
        }

